import {
  boolean,
  doublePrecision,
  index,
  integer,
  jsonb,
  pgTable,
  text,
  timestamp,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const reportsTable = pgTable(
  "reports",
  {
    id: text("id").primaryKey(),
    imageUrl: text("image_url"),
    hazardType: text("hazard_type").notNull(),
    confidence: doublePrecision("confidence"),
    severity: text("severity").notNull(),
    explanation: text("explanation"),
    verificationStatus: text("verification_status").notNull(),
    latitude: doublePrecision("latitude").notNull(),
    longitude: doublePrecision("longitude").notNull(),
    locationName: text("location_name").notNull(),
    description: text("description"),
    rainfallMm: doublePrecision("rainfall_mm"),
    rainfallSource: text("rainfall_source"),
    rainfallIsFallback: boolean("rainfall_is_fallback").notNull().default(false),
    riskScore: integer("risk_score").notNull(),
    riskComponents: jsonb("risk_components")
      .$type<{
        severity: number;
        recent_density: number;
        historical_frequency: number;
        rainfall: number;
        recency: number;
      }>()
      .notNull(),
    status: text("status").notNull().default("reported"),
    isDemo: boolean("is_demo").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    index("reports_created_at_idx").on(table.createdAt),
    index("reports_status_idx").on(table.status),
    index("reports_severity_idx").on(table.severity),
    index("reports_hazard_type_idx").on(table.hazardType),
  ],
);

export const insertReportSchema = createInsertSchema(reportsTable);
export type InsertReport = z.infer<typeof insertReportSchema>;
export type Report = typeof reportsTable.$inferSelect;