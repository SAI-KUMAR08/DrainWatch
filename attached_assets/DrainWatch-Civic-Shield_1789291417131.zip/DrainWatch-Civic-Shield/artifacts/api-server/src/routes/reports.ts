import { Router, type IRouter } from "express";
import {
  CreateReportBody,
  GetReportParams,
  GetReportResponse,
  ListReportsQueryParams,
  ListReportsResponse,
  UpdateReportStatusBody,
  UpdateReportStatusParams,
  UpdateReportStatusResponse,
} from "@workspace/api-zod";
import { db, reportsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import {
  getReports,
  insertReport,
  reportStatuses,
  toReportResponse,
} from "../lib/drainwatch";

const router: IRouter = Router();

router.get("/reports", async (req, res): Promise<void> => {
  const parsed = ListReportsQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const reports = await getReports(parsed.data);
  res.json(ListReportsResponse.parse(reports.map(toReportResponse)));
});

router.post("/reports", async (req, res): Promise<void> => {
  const parsed = CreateReportBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const report = await insertReport(parsed.data);
  res.status(201).json(GetReportResponse.parse(toReportResponse(report)));
});

router.get("/reports/:id", async (req, res): Promise<void> => {
  const params = GetReportParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [report] = await db
    .select()
    .from(reportsTable)
    .where(eq(reportsTable.id, params.data.id))
    .limit(1);
  if (!report) {
    res.status(404).json({ error: "Report not found" });
    return;
  }

  res.json(GetReportResponse.parse(toReportResponse(report)));
});

router.patch("/reports/:id/status", async (req, res): Promise<void> => {
  const params = UpdateReportStatusParams.safeParse(req.params);
  const body = UpdateReportStatusBody.safeParse(req.body);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  if (!reportStatuses.includes(body.data.status as (typeof reportStatuses)[number])) {
    res.status(400).json({ error: "Unsupported report status" });
    return;
  }

  const [updated] = await db
    .update(reportsTable)
    .set({ status: body.data.status, updatedAt: new Date() })
    .where(eq(reportsTable.id, params.data.id))
    .returning();
  if (!updated) {
    res.status(404).json({ error: "Report not found" });
    return;
  }

  res.json(UpdateReportStatusResponse.parse(toReportResponse(updated)));
});

export default router;