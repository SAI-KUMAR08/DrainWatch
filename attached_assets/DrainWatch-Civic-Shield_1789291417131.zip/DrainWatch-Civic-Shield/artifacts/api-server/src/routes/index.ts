import { Router, type IRouter } from "express";
import healthRouter from "./health";
import reportsRouter from "./reports";
import intelligenceRouter from "./intelligence";

const router: IRouter = Router();

router.use(healthRouter);
router.use(reportsRouter);
router.use(intelligenceRouter);

export default router;
