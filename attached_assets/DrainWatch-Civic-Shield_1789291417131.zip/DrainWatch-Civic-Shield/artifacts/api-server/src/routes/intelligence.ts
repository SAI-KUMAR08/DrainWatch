import { Router, type IRouter } from "express";
import {
  GetConfigStatusResponse,
  GetDashboardStatsResponse,
  GetWeatherResponse,
  ListActivityQueryParams,
  ListActivityResponse,
  ListHotspotsResponse,
} from "@workspace/api-zod";
import { db, reportsTable } from "@workspace/db";
import { desc, sql } from "drizzle-orm";
import { currentWeather, toReportResponse } from "../lib/drainwatch";

const router: IRouter = Router();

router.get("/dashboard/stats", async (_req, res): Promise<void> => {
  const reports = await db.select().from(reportsTable);
  const weather = currentWeather();
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  res.json(
    GetDashboardStatsResponse.parse({
      rainfall_mm: weather.rainfallMm,
      rainfall_source: weather.source,
      rainfall_is_fallback: weather.isFallback,
      active_hazards: reports.filter((report) => !["resolved", "rejected"].includes(report.status)).length,
      cleared_today: reports.filter((report) => report.status === "resolved" && report.updatedAt >= today).length,
      critical_reports: reports.filter((report) => report.severity === "critical").length,
      ai_verified_reports: reports.filter((report) => report.verificationStatus === "ai_verified").length,
      total_reports: reports.length,
    }),
  );
});

router.get("/activity", async (req, res): Promise<void> => {
  const parsed = ListActivityQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const reports = await db.select().from(reportsTable).orderBy(desc(reportsTable.createdAt)).limit(parsed.data.limit);
  res.json(
    ListActivityResponse.parse(
      reports.map((report) => ({
        id: report.id,
        report_id: report.id,
        text: `${report.hazardType.replaceAll("_", " ")} reported in ${report.locationName}`,
        severity: report.severity,
        status: report.status,
        created_at: report.createdAt,
      })),
    ),
  );
});

router.get("/hotspots", async (_req, res): Promise<void> => {
  const reports = await db.select().from(reportsTable);
  const groups = new Map<string, typeof reports>();
  for (const report of reports) {
    const key = report.locationName || `${report.latitude.toFixed(2)},${report.longitude.toFixed(2)}`;
    const group = groups.get(key) ?? [];
    group.push(report);
    groups.set(key, group);
  }
  res.json(
    ListHotspotsResponse.parse(
      [...groups.entries()]
        .map(([label, group]) => {
          const top = [...group].sort((a, b) => b.riskScore - a.riskScore)[0];
          return {
            id: label.toLowerCase().replaceAll(" ", "-"),
            label,
            latitude: top.latitude,
            longitude: top.longitude,
            risk_score: Math.max(...group.map((report) => report.riskScore)),
            report_count: group.length,
            critical_count: group.filter((report) => report.severity === "critical").length,
            rainfall_mm: top.rainfallMm,
            rainfall_is_fallback: top.rainfallIsFallback,
          };
        })
        .sort((a, b) => b.risk_score - a.risk_score)
        .slice(0, 8),
    ),
  );
});

router.get("/weather", (_req, res) => {
  const weather = currentWeather();
  res.json(
    GetWeatherResponse.parse({
      rainfall_mm: weather.rainfallMm,
      period: "24h",
      source: weather.source,
      is_fallback: weather.isFallback,
      status: "unavailable",
      rain_risk: null,
      observed_at: null,
    }),
  );
});

router.get("/config/status", async (_req, res) => {
  const dbResult = await db.select({ count: sql<number>`count(*)` }).from(reportsTable);
  res.json(
    GetConfigStatusResponse.parse({
      ai_available: false,
      weather_available: false,
      database_available: dbResult.length === 1,
      image_storage_available: false,
    }),
  );
});

export default router;