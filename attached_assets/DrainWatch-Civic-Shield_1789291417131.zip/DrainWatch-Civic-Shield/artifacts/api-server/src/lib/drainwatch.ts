import { randomUUID } from "node:crypto";
import { and, desc, eq, sql } from "drizzle-orm";
import { db, reportsTable, type Report } from "@workspace/db";

export const reportStatuses = [
  "reported",
  "verified",
  "assigned",
  "in_progress",
  "resolved",
  "rejected",
] as const;

type Severity = "critical" | "high" | "medium" | "low" | "unknown";

const severityValue: Record<Severity, number> = {
  critical: 100,
  high: 80,
  medium: 55,
  low: 30,
  unknown: 20,
};

export function currentWeather() {
  return {
    rainfallMm: null as number | null,
    source: null as string | null,
    isFallback: true,
  };
}

export function calculateRisk(
  severity: Severity,
  recentReports: number,
  historicalReports: number,
  rainfallMm: number | null,
  createdAt = new Date(),
) {
  const components = {
    severity: severityValue[severity],
    recent_density: Math.min(recentReports * 18, 100),
    historical_frequency: Math.min(historicalReports * 12, 100),
    rainfall: rainfallMm == null ? 0 : Math.min(rainfallMm * 2, 100),
    recency: Math.max(
      0,
      100 - Math.floor((Date.now() - createdAt.getTime()) / 86_400_000) * 20,
    ),
  };

  const score = Math.round(
    components.severity * 0.3 +
      components.recent_density * 0.25 +
      components.historical_frequency * 0.2 +
      components.rainfall * 0.15 +
      components.recency * 0.1,
  );

  return { score: Math.max(0, Math.min(100, score)), components };
}

export function toReportResponse(report: Report) {
  return {
    id: report.id,
    image_url: report.imageUrl,
    hazard_type: report.hazardType,
    confidence: report.confidence,
    severity: report.severity,
    explanation: report.explanation,
    verification_status: report.verificationStatus,
    latitude: report.latitude,
    longitude: report.longitude,
    location_name: report.locationName,
    description: report.description,
    rainfall_mm: report.rainfallMm,
    rainfall_source: report.rainfallSource,
    rainfall_is_fallback: report.rainfallIsFallback,
    risk_score: report.riskScore,
    risk_components: report.riskComponents,
    status: report.status,
    is_demo: report.isDemo,
    created_at: report.createdAt,
    updated_at: report.updatedAt,
  };
}

export async function insertReport(input: {
  image_url?: string | null;
  hazard_type: string;
  confidence?: number | null;
  severity: Severity;
  explanation?: string | null;
  verification_status?: string;
  latitude: number;
  longitude: number;
  location_name: string;
  description?: string | null;
  is_demo?: boolean;
}) {
  const weather = currentWeather();
  const [recentCount] = await db
    .select({ count: sql<number>`count(*)` })
    .from(reportsTable)
    .where(sql`${reportsTable.createdAt} > now() - interval '24 hours'`);
  const [historicalCount] = await db
    .select({ count: sql<number>`count(*)` })
    .from(reportsTable);
  const risk = calculateRisk(
    input.severity,
    Number(recentCount?.count ?? 0) + 1,
    Number(historicalCount?.count ?? 0) + 1,
    weather.rainfallMm,
  );
  const now = new Date();
  const [created] = await db
    .insert(reportsTable)
    .values({
      id: randomUUID(),
      imageUrl: input.image_url ?? null,
      hazardType: input.hazard_type,
      confidence: input.confidence ?? null,
      severity: input.severity,
      explanation:
        input.explanation ??
        "Citizen-submitted report. AI analysis is not configured for this deployment.",
      verificationStatus: input.verification_status ?? "unavailable",
      latitude: input.latitude,
      longitude: input.longitude,
      locationName: input.location_name,
      description: input.description ?? null,
      rainfallMm: weather.rainfallMm,
      rainfallSource: weather.source,
      rainfallIsFallback: weather.isFallback,
      riskScore: risk.score,
      riskComponents: risk.components,
      status: "reported",
      isDemo: input.is_demo ?? false,
      createdAt: now,
      updatedAt: now,
    })
    .returning();

  return created;
}

export async function getReports(filters: {
  severity?: string;
  hazard_type?: string;
  status?: string;
  limit: number;
}) {
  const conditions = [];
  if (filters.severity) conditions.push(eq(reportsTable.severity, filters.severity));
  if (filters.hazard_type) conditions.push(eq(reportsTable.hazardType, filters.hazard_type));
  if (filters.status) conditions.push(eq(reportsTable.status, filters.status));

  return db
    .select()
    .from(reportsTable)
    .where(conditions.length ? and(...conditions) : undefined)
    .orderBy(desc(reportsTable.createdAt))
    .limit(filters.limit);
}