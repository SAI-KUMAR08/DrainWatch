---
name: DrainWatch build notes
description: Non-obvious constraints for continuing the DrainWatch civic-safety MVP.
---

The app deliberately uses the workspace's provisioned PostgreSQL/Drizzle stack instead of introducing a second database. AI, weather, and image storage are explicit unavailable states until real providers are configured; demo reports are the only seeded values and are marked as demo data.

**Why:** The product is safety-adjacent, so fabricated confidence, rainfall, coordinates, or government integration would undermine technical credibility.

**How to apply:** Preserve structured unavailable states and backend-owned risk calculations when adding providers or new UI.